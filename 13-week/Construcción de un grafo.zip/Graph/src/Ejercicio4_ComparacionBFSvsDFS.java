// Ejercicio4_ComparacionBFSvsDFS.java
// Implementa DFS (ya incluida en Graph) y compara órdenes de recorrido.
import java.util.List;

public class Ejercicio4_ComparacionBFSvsDFS {
    public static void main(String[] args) {
        Graph g = new Graph();
        g.addEdge("1","2");
        g.addEdge("1","3");
        g.addEdge("2","4");
        g.addEdge("2","5");
        g.addEdge("3","6");
        g.addEdge("3","7");
        System.out.println("Grafo:");
        System.out.println(g);
        List<String> bfsOrder = g.bfs("1");
        List<String> dfsOrder = g.dfs("1");
        System.out.println("BFS desde 1: " + bfsOrder); // nivel por nivel
        System.out.println("DFS desde 1: " + dfsOrder); // profundidad
    }
}
