// Ejercicio1_RedSocial.java
// Modela una red social simple: usuarios como nodos, amistades como aristas.
// Muestra recorrido BFS desde un usuario inicial.
import java.util.List;

public class Ejercicio1_RedSocial {
    public static void main(String[] args) {
        Graph red = new Graph();
        // usuarios
        String[] usuarios = {"Luis","Ana","Carlos","María","Sofía","Diego"};
        for (String u : usuarios) red.addVertex(u);
        // amistades (no dirigidas)
        red.addEdge("Luis","Ana");
        red.addEdge("Luis","Carlos");
        red.addEdge("Ana","María");
        red.addEdge("Carlos","Sofía");
        red.addEdge("María","Diego");
        // BFS desde "Luis"
        List<String> recorrido = red.bfs("Luis");
        System.out.println("Recorrido BFS desde Luis en la red social:");
        System.out.println(recorrido);
    }
}
