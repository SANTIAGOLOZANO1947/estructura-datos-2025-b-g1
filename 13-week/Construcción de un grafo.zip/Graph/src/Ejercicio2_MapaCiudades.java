// Ejercicio2_MapaCiudades.java
// Representa un mapa de ciudades conectadas y muestra BFS desde la ciudad origen.
import java.util.List;

public class Ejercicio2_MapaCiudades {
    public static void main(String[] args) {
        Graph mapa = new Graph();
        String[] ciudades = {"Bogota","Medellin","Cali","Pereira","Armenia","Manizales"};
        for (String c : ciudades) mapa.addVertex(c);
        mapa.addEdge("Bogota","Medellin");
        mapa.addEdge("Bogota","Pereira");
        mapa.addEdge("Pereira","Armenia");
        mapa.addEdge("Pereira","Manizales");
        mapa.addEdge("Medellin","Cali"); // conexión ejemplo (no realista)
        // BFS desde "Bogota"
        List<String> recorrido = mapa.bfs("Bogota");
        System.out.println("Recorrido BFS desde Bogota:");
        System.out.println(recorrido);
    }
}
