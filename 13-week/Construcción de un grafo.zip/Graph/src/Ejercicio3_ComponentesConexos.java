// Ejercicio3_ComponentesConexos.java
// Construye un grafo no conexo y muestra BFS desde nodos de distintos componentes.
import java.util.List;

public class Ejercicio3_ComponentesConexos {
    public static void main(String[] args) {
        Graph g = new Graph();
        // Componente 1
        g.addEdge("A","B");
        g.addEdge("B","C");
        // Componente 2
        g.addEdge("X","Y");
        g.addEdge("Y","Z");
        // Nodo aislado
        g.addVertex("Solo");
        System.out.println("Grafo:");
        System.out.println(g);
        System.out.println("BFS desde A (componente 1): " + g.bfs("A"));
        System.out.println("BFS desde X (componente 2): " + g.bfs("X"));
        System.out.println("BFS desde Solo (aislado): " + g.bfs("Solo"));
    }
}
