# Taller — Construcción de un Grafo y Recorrido BFS (Breadth-First Search)

---

## Descripción general

Este proyecto corresponde a la **Unidad 3 — Estructuras de Datos: Grafos y Algoritmos de Recorrido**, cuyo propósito es que el estudiante implemente un **grafo no dirigido** y el algoritmo **Breadth-First Search (BFS)** en el lenguaje **Java**.

El algoritmo BFS recorre los nodos **por niveles** y permite encontrar **rutas mínimas en grafos no ponderados**, siendo una de las estrategias fundamentales en el análisis de redes, mapas, conexiones sociales y sistemas de comunicación.

---

## Objetivos del taller

- Comprender la estructura y representación de un **grafo** mediante **listas de adyacencia**.
- Implementar el algoritmo **BFS** utilizando una **cola (Queue)**.
- Analizar la **eficiencia temporal y espacial** del recorrido BFS.
- Aplicar el conocimiento en **cuatro ejercicios prácticos** con diferentes contextos.
- Documentar y evaluar el comportamiento del algoritmo.

---

## Estructura del proyecto
El proyecto taller-grafo-bfs consiste en implementar un grafo no dirigido en Java y aplicar
el algoritmo BFS (Breadth-First Search) para recorrer sus nodos. Incluye clases para crear vértices,
agregar aristas y realizar el recorrido en anchura. Además, desarrolla cuatro ejercicios prácticos
sobre redes sociales, mapas de ciudades, componentes conexos y comparación con DFS. El objetivo es comprender
la estructura de los grafos y analizar la eficiencia del algoritmo BFS.

![img.png](img.png)


---

## Ejercicios desarrollados
### Ejercicio 1 — Red social simple

Modela usuarios como nodos y amistades como aristas.
Permite recorrer la red desde un usuario inicial y observar el orden de amistad por niveles.

Ejemplo:

Usuarios: Ana, Beto, Carla, Diego, Elsa
Amistades: Ana-Beto, Ana-Carla, Beto-Diego, Carla-Elsa

Recorrido BFS desde Ana → [Ana, Beto, Carla, Diego, Elsa]

### Ejercicio 2 — Mapa de ciudades

Cada ciudad es un nodo y las carreteras son aristas.
BFS permite explorar qué ciudades son accesibles desde una ciudad origen.

Ejemplo:

Bogotá — Medellín — Cali — Barranquilla — Bucaramanga

BFS desde Bogotá → [Bogotá, Medellín, Cali, Barranquilla, Bucaramanga]

### Ejercicio 3 — Componentes conexos

Prueba un grafo que no está totalmente conectado.
Permite ver cómo BFS se detiene al terminar una componente y no visita los nodos aislados.

Ejemplo:

Componente 1: A-B-C
Componente 2: X-Y

BFS desde A → [A, B, C]

### Ejercicio 4 — Comparación BFS vs DFS

Implementa también un recorrido DFS (Depth-First Search) y compara el orden de visita.
Algoritmo	Estructura usada	Tipo de recorrido	Orden típico
BFS	Cola (Queue)	Por niveles	[A, B, C, D]
DFS	Pila (Stack)	En profundidad	[A, B, D, C]
### Análisis de complejidad
Operación	Descripción	Pasos aprox.	Complejidad
addVertex()	Inserta un nuevo nodo	1 paso	O(1)
addEdge()	Conecta dos nodos	1 paso	O(1)
bfs()	Recorre todos los nodos y aristas	V + E pasos	O(V + E)

El algoritmo BFS recorre cada vértice y arista una sola vez, lo que lo hace muy eficiente en comparación con otros métodos de búsqueda.

## Clases principales

`Graph.java`
Implementa la estructura del grafo mediante un **HashMap** donde cada vértice tiene una lista de adyacencia.  
Incluye los métodos:

#### Implementa también un recorrido DFS (Depth-First Search) y compara el orden de visita.

Algoritmo	Estructura usada	Tipo de recorrido	Orden típico
BFS	Cola (Queue)	Por niveles	[A, B, C, D]
DFS	Pila (Stack)	En profundidad	[A, B, D, C]

## Análisis de complejidad

Operación	Descripción	Pasos aprox.	Complejidad
addVertex()	Inserta un nuevo nodo	1 paso	O(1)
addEdge()	Conecta dos nodos	1 paso	O(1)
bfs()	Recorre todos los nodos y aristas	V + E pasos	O(V + E)

#### Nombre del estudiante: Santiago lozano Mantilla, Juan David Moreno Botello                       
#### Asignatura: Estructuras de Datos
#### Lenguaje: Java
#### Institución: CORHUILA ; Corporacion Universitaria Del Huila
#### Año: 2025