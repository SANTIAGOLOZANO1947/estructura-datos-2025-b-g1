// BFSExample.java
public class BFSExample {
    public static void main(String[] args) {
        Graph g = new Graph();
        g.addVertex("A"); g.addVertex("B"); g.addVertex("C"); g.addVertex("D");
        g.addEdge("A","B"); g.addEdge("A","C"); g.addEdge("B","D");
        System.out.println("Grafo (lista de adyacencia):");
        System.out.println(g);
        System.out.println("Recorrido BFS desde A:");
        System.out.println(g.bfs("A")); // Esperado: [A, B, C, D]
        System.out.println("Recorrido DFS desde A:");
        System.out.println(g.dfs("A")); // Posible: [A, B, D, C]
    }
}
