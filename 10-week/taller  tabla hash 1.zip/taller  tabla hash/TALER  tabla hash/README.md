# Taller - Tabla Hash (Estructuras de Datos)

Este proyecto implementa una **tabla hash genérica** `<K, V>` utilizando **encadenamiento** (listas enlazadas) para resolver colisiones.  
Desarrollado en **Java** como parte del taller de estructuras de datos.

---

## 🔧 Estructura del proyecto
